



// Test away!
import React from 'react';
import ReactDOM from 'react-dom';
import Controls from './Controls';
//import Display from '../display/Display';
import { render, fireEvent } from 'react-testing-library';
import 'jest-dom/extend-expect';

 /* describe('renders the Display without crashing', () => {
  it('renders without crashing', () => {
    const div = document.createElement('div');
    ReactDOM.render(<Display />, div);
    ReactDOM.unmountComponentAtNode(div);
  });

}) */

describe('renders the Controls without crashing', () => {
    it('renders without crashing', () => {
      const div = document.createElement('div');
      ReactDOM.render(<Controls />, div);
      ReactDOM.unmountComponentAtNode(div);
    });
  
  }) 
