// Test away!
import React from 'react';
import ReactDOM from 'react-dom';
//import Dashboard from './dashboard';
import Display from './display';
import { render } from 'react-testing-library';
import 'jest-dom/extend-expect';

 describe('renders the Display without crashing', () => {
  it('renders without crashing', () => {
    const div = document.createElement('div');
    ReactDOM.render(<Display />, div);
    ReactDOM.unmountComponentAtNode(div);
  });





/* describe('the Button components', () => {
  test('the ball button increases ball number', () => {
    const component = render(<Display />);
    const component2 = render(<Dashboard />);
    
    const button = component2.getByTestId('ballcounter');
    fireEvent.click(button);
    const balls = component.getByTestId('balls')
    expect(balls).toHaveTextContent('1');
  }) */

});